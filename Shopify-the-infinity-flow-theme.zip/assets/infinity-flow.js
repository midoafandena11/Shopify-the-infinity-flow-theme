/* Infinity Flow: plus-to-add and drag products to the floating cart. */
(() => {
  'use strict';
  if (window.__infinityFlowInit) return;
  window.__infinityFlowInit = true;
  const cartUrl = (window.Shopify && window.Shopify.routes && window.Shopify.routes.root) ? window.Shopify.routes.root + 'cart.js' : '/cart.js';
  const addUrl = (window.Shopify && window.Shopify.routes && window.Shopify.routes.root) ? window.Shopify.routes.root + 'cart/add.js' : '/cart/add.js';
  const icon = (name) => ({
    home:'<path d="m3 10 9-7 9 7v10a1 1 0 0 1-1 1h-5v-7H9v7H4a1 1 0 0 1-1-1z"/>',
    search:'<circle cx="10.8" cy="10.8" r="6.8"/><path d="m16 16 5 5"/>',
    grid:'<rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/>',
    cart:'<path d="M3 4h2l2.2 10.2a2 2 0 0 0 2 1.6h7.9a2 2 0 0 0 1.9-1.4L21 8H6"/><circle cx="10" cy="20" r="1"/><circle cx="18" cy="20" r="1"/>',
    user:'<circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0 1 16 0"/>'
  }[name] || '');
  const svg = name => '<svg viewBox="0 0 24 24" aria-hidden="true">'+icon(name)+'</svg>';
  function toast(message){ let el=document.querySelector('.if-toast'); if(!el){el=document.createElement('div');el.className='if-toast';el.setAttribute('role','status');document.body.appendChild(el)} el.textContent=message;el.classList.add('is-visible');clearTimeout(el._timer);el._timer=setTimeout(()=>el.classList.remove('is-visible'),2200); }
  function getCardData(card){
    const image=card.querySelector('.card__media img, img');
    const imageUrl=image && (image.currentSrc || image.src);
    const title=(card.querySelector('.card__heading a, .card__heading, .full-unstyled-link')?.textContent || '').trim();
    let variant=card.dataset.ifVariant || card.querySelector('input[name="id"]')?.value || '';
    const productUrl=card.querySelector('a[href*="/products/"]')?.href || '';
    return {imageUrl,title,variant,productUrl};
  }
  async function addItem(data, button){
    let variant=data.variant;
    if(!variant && data.productUrl){
      try { const res=await fetch(data.productUrl+'.js',{headers:{Accept:'application/json'}}); if(res.ok){const product=await res.json();const available=(product.variants||[]).find(v=>v.available);variant=available&&available.id;} } catch(e){}
    }
    if(!variant){ if(data.productUrl){window.location.href=data.productUrl;return} toast('افتح المنتج لاختيار المتغيرات');return; }
    if(button)button.disabled=true;
    try{
      const res=await fetch(addUrl,{method:'POST',headers:{'Content-Type':'application/json','Accept':'application/json'},body:JSON.stringify({items:[{id:Number(variant),quantity:1}]})});
      if(!res.ok){let err={};try{err=await res.json()}catch(e){} throw new Error(err.description||'تعذر إضافة المنتج');}
      toast('تمت إضافة المنتج إلى السلة');
      document.dispatchEvent(new CustomEvent('infinity-flow:added',{detail:{variant}}));
      await refreshCount();
      const drawer=document.querySelector('cart-drawer');
      if(drawer && typeof drawer.open==='function') { try { drawer.open(); } catch(e){} }
      document.dispatchEvent(new CustomEvent('cart:refresh'));
    }catch(e){toast(e.message||'تعذر إضافة المنتج للسلة');}
    finally{if(button)button.disabled=false;}
  }
  async function refreshCount(){
    try{const r=await fetch(cartUrl,{headers:{Accept:'application/json'}});if(!r.ok)return;const cart=await r.json();document.querySelectorAll('.if-cart-count').forEach(el=>el.textContent=cart.item_count);document.querySelectorAll('#cart-icon-bubble .cart-count-bubble span[aria-hidden="true"]').forEach(el=>el.textContent=cart.item_count);document.querySelectorAll('#cart-icon-bubble .cart-count-bubble').forEach(el=>el.classList.toggle('hidden',!cart.item_count));}catch(e){}
  }
  function makePlus(card){
    if(card.dataset.ifEnhanced==='1')return;card.dataset.ifEnhanced='1';
    const area=card.querySelector('.card__inner')||card.querySelector('.card__media')||card;
    if(!area)return;
    const btn=document.createElement('button');btn.type='button';btn.className='if-card-plus';btn.setAttribute('aria-label','إضافة المنتج إلى السلة');btn.textContent='+';btn.addEventListener('click',e=>{e.preventDefault();e.stopPropagation();addItem(getCardData(card),btn)});
    area.appendChild(btn);
  }
  function enhanceCards(){document.querySelectorAll('.card-wrapper.product-card-wrapper, .product-grid .card-wrapper, .grid__item .card-wrapper').forEach(makePlus);}
  function createNav(){
    if(document.querySelector('.if-bottom-nav'))return;
    const nav=document.createElement('nav');nav.className='if-bottom-nav';nav.setAttribute('aria-label','التنقل الرئيسي');
    const links=[['home','الرئيسية','/'],['search','بحث','/search'],['grid','التصنيفات','/collections/all'],['cart','السلة','/cart'],['user','حسابي','/account']];
    links.forEach(([ic,label,url])=>{const a=document.createElement('a');a.href=url;a.innerHTML=svg(ic)+'<span>'+label+'</span>';if(location.pathname===url || (url==='/'&&location.pathname==='/'))a.setAttribute('aria-current','page');if(url==='/search')a.addEventListener('click',e=>{const form=document.querySelector('predictive-search form, form[role="search"], .search-modal__form');if(form)return;});nav.appendChild(a)});
    document.body.appendChild(nav);
  }
  function createFloatingCart(){
    if(document.querySelector('.if-floating-cart'))return;
    const b=document.createElement('button');b.type='button';b.className='if-floating-cart';b.setAttribute('aria-label','السلة - اسحب المنتج هنا');b.innerHTML=svg('cart')+'<span class="if-cart-count">0</span>';
    b.addEventListener('click',()=>{const drawer=document.querySelector('cart-drawer');if(drawer&&typeof drawer.open==='function'){drawer.open();return}window.location.href='/cart'});
    document.body.appendChild(b);refreshCount();
  }
  let drag=null;
  let suppressClickUntil=0;
  document.addEventListener('click',e=>{if(Date.now()<suppressClickUntil && e.target.closest('.card-wrapper.product-card-wrapper, .product-grid .card-wrapper, .grid__item .card-wrapper')){e.preventDefault();e.stopPropagation();}},true);
  function startDrag(e,card){
    if(e.button!==undefined&&e.button!==0)return;
    const data=getCardData(card);if(!data.imageUrl)return;
    const startX=e.clientX,startY=e.clientY;let moved=false,ghost=null;
    const move=ev=>{
      const dx=ev.clientX-startX,dy=ev.clientY-startY;
      if(!moved&&Math.hypot(dx,dy)<10)return;
      if(!moved){moved=true;ghost=document.createElement('div');ghost.className='if-drag-ghost';ghost.innerHTML='<img alt="" src="'+data.imageUrl.replace(/"/g,'&quot;')+'">';document.body.appendChild(ghost);document.querySelector('.if-floating-cart')?.classList.add('is-drop-ready');card.classList.add('if-is-dragging');}
      if(ghost){ghost.style.left=ev.clientX+'px';ghost.style.top=ev.clientY+'px';}
      const target=document.querySelector('.if-floating-cart');if(target){const r=target.getBoundingClientRect();target.classList.toggle('is-drop-ready',ev.clientX>=r.left-25&&ev.clientX<=r.right+25&&ev.clientY>=r.top-25&&ev.clientY<=r.bottom+25)}
      if(moved)ev.preventDefault();
    };
    const end=ev=>{
      document.removeEventListener('pointermove',move);document.removeEventListener('pointerup',end);document.removeEventListener('pointercancel',end);
      document.querySelector('.if-floating-cart')?.classList.remove('is-drop-ready');card.classList.remove('if-is-dragging');if(ghost)ghost.remove();
      if(moved){suppressClickUntil=Date.now()+500;const target=document.querySelector('.if-floating-cart');if(target){const r=target.getBoundingClientRect();if(ev.clientX>=r.left-25&&ev.clientX<=r.right+25&&ev.clientY>=r.top-25&&ev.clientY<=r.bottom+25)addItem(data,null);} }
      drag=null;
    };
    document.addEventListener('pointermove',move,{passive:false});document.addEventListener('pointerup',end);document.addEventListener('pointercancel',end);drag={};
  }
  document.addEventListener('pointerdown',e=>{
    if(e.target.closest('button,input,select,textarea,.if-card-plus,.quick-add'))return;
    if(e.target.closest('a') && !e.target.closest('.card__media'))return;
    const card=e.target.closest('.card-wrapper.product-card-wrapper, .product-grid .card-wrapper, .grid__item .card-wrapper');if(!card)return;
    startDrag(e,card);
  },{passive:true});
  function init(){enhanceCards();createNav();createFloatingCart();}
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init,{once:true});else init();
  const observer=new MutationObserver(()=>{enhanceCards();});observer.observe(document.documentElement,{childList:true,subtree:true});
})();
